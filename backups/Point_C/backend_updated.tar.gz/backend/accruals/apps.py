from django.apps import AppConfig


class AccrualsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accruals'
    verbose_name = 'Начисления'
