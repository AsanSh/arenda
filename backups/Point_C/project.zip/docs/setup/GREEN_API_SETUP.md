# Настройка Green API для WhatsApp авторизации

## 🔑 Данные Green API

- **ID Instance:** `7107486710`
- **API Token Instance:** `6633644896594f7db36235195f23579325e7a9498eab4411bd`

## 📋 Шаги настройки

### 1. Применить миграции (ОБЯЗАТЕЛЬНО!)

```bash
cd /root/arenda/infra
docker compose exec backend python manage.py migrate core
```

Это создаст таблицу `login_attempts` в базе данных.

### 2. Настроить Webhook в Green API

1. Откройте https://console.green-api.com/
2. Войдите в аккаунт
3. Найдите instance с ID: `7107486710`
4. Перейдите в настройки instance
5. Найдите раздел **"Webhook"** или **"Входящие уведомления"**
6. Укажите Webhook URL:
   ```
   http://assetmanagement.team/api/webhooks/greenapi/incoming/
   ```
   Или если SSL настроен:
   ```
   https://assetmanagement.team/api/webhooks/greenapi/incoming/
   ```
7. Включите **"Входящие уведомления"** (Incoming notifications)
8. Сохраните изменения

### 3. Проверить работу

1. Откройте `http://assetmanagement.team/login`
2. Должен появиться QR-код с текстом "AMT LOGIN <attemptId>"
3. Отсканируйте QR-код в WhatsApp
4. Отправьте предзаполненное сообщение
5. Система автоматически определит ваш номер и роль

## 🔍 Проверка настроек

### Проверка миграций

```bash
cd /root/arenda/infra
docker compose exec backend python manage.py showmigrations core
```

Должна быть миграция `0005_loginattempt` со статусом `[X]`.

### Проверка таблицы в БД

```bash
cd /root/arenda/infra
docker compose exec backend python manage.py dbshell
```

В PostgreSQL:
```sql
\dt login_attempts
-- Должна показать таблицу login_attempts
```

### Проверка webhook

```bash
# Проверьте, что endpoint доступен
curl -X POST http://assetmanagement.team/api/webhooks/greenapi/incoming/ \
  -H "Content-Type: application/json" \
  -d '{"typeWebhook":"test"}'
```

Должен вернуть статус 200 (даже если webhook игнорируется).

## ⚠️ Важно

1. **Миграции обязательны** - без них таблица `login_attempts` не будет создана
2. **Webhook должен быть доступен из интернета** - Green API должен иметь возможность отправлять запросы на ваш сервер
3. **Для локальной разработки** используйте ngrok:
   ```bash
   ngrok http 8000
   # Используйте полученный HTTPS URL для webhook
   ```

## 🐛 Troubleshooting

### Ошибка: "relation login_attempts does not exist"

**Решение:** Примените миграции:
```bash
cd /root/arenda/infra
docker compose exec backend python manage.py migrate
```

### Ошибка: "Ошибка при создании попытки входа"

**Причины:**
1. Миграции не применены
2. Backend не запущен
3. Проблемы с базой данных

**Решение:**
```bash
# Проверьте backend
docker compose ps backend

# Примените миграции
docker compose exec backend python manage.py migrate

# Проверьте логи
docker compose logs backend
```

### Webhook не работает

**Проверьте:**
1. Webhook URL правильный в настройках Green API
2. URL доступен из интернета (не localhost)
3. Nginx правильно проксирует запросы на backend
4. Backend запущен и отвечает

**Тест:**
```bash
curl -X POST http://assetmanagement.team/api/webhooks/greenapi/incoming/ \
  -H "Content-Type: application/json" \
  -d '{"typeWebhook":"incomingMessageReceived","messageData":{"textMessageData":{"textMessage":"AMT LOGIN test-123"}},"senderData":{"sender":"996557903999"}}'
```

## 📝 Формат сообщения для входа

Пользователь должен отправить сообщение в формате:
```
AMT LOGIN <attemptId>
```

Где `<attemptId>` - это UUID, который генерируется при создании попытки входа.

## ✅ После настройки

1. ✅ Миграции применены
2. ✅ Webhook настроен в Green API
3. ✅ Backend запущен
4. ✅ Nginx проксирует запросы правильно
5. ✅ Сайт доступен по домену

Теперь вход через WhatsApp должен работать!
