# 🚀 Настройка Green API - Пошаговая инструкция

## ✅ Шаг 1: Миграции применены

Миграция `0005_loginattempt` успешно применена. Таблица `login_attempts` создана.

## 📋 Шаг 2: Настройка Webhook в Green API

### 2.1 Войдите в личный кабинет Green API

1. Откройте: https://console.green-api.com/
2. Войдите в свой аккаунт

### 2.2 Найдите ваш instance

- **ID Instance:** `7107486710`
- **API Token Instance:** `6633644896594f7db36235195f23579325e7a9498eab4411bd`

### 2.3 Настройте Webhook URL

1. Перейдите в настройки instance `7107486710`
2. Найдите раздел **"Webhook"** или **"Входящие уведомления"** (Incoming notifications)
3. В поле **"Webhook URL"** укажите:

   **Для продакшена (HTTP):**
   ```
   http://assetmanagement.team/api/webhooks/greenapi/incoming/
   ```

   **Для продакшена (после настройки SSL):**
   ```
   https://assetmanagement.team/api/webhooks/greenapi/incoming/
   ```

4. Включите **"Входящие уведомления"** (Incoming notifications)
5. Сохраните изменения

### 2.4 Проверьте настройки

Убедитесь, что:
- ✅ Webhook URL указан правильно
- ✅ Входящие уведомления включены
- ✅ Тип webhook: `HTTP` (не WebSocket)

## 🧪 Шаг 3: Проверка работы

### 3.1 Проверка endpoint создания попытки

```bash
curl -X POST http://assetmanagement.team/api/auth/whatsapp/start/ \
  -H "Content-Type: application/json"
```

**Ожидаемый ответ:**
```json
{
  "attemptId": "uuid-здесь",
  "expiresAt": "2026-01-23T17:30:00Z",
  "loginMessage": "AMT LOGIN uuid-здесь",
  "qrPayload": "AMT LOGIN uuid-здесь"
}
```

### 3.2 Проверка webhook endpoint

```bash
curl -X POST http://assetmanagement.team/api/webhooks/greenapi/incoming/ \
  -H "Content-Type: application/json" \
  -d '{"typeWebhook":"test"}'
```

Должен вернуть статус 200 (даже если webhook игнорируется).

### 3.3 Тест полного цикла

1. Откройте `http://assetmanagement.team/login`
2. Должен появиться QR-код с текстом "AMT LOGIN <attemptId>"
3. Отсканируйте QR-код в WhatsApp
4. Отправьте предзаполненное сообщение
5. Система автоматически определит ваш номер и роль

## 📝 Формат сообщения

Пользователь должен отправить в WhatsApp сообщение в формате:
```
AMT LOGIN <attemptId>
```

Где `<attemptId>` - это UUID из QR-кода.

## 🔍 Troubleshooting

### Проблема: Webhook не получает сообщения

**Проверьте:**
1. Webhook URL правильный и доступен из интернета
2. Nginx правильно проксирует запросы на backend
3. Backend запущен: `docker compose ps backend`
4. Проверьте логи: `docker compose logs backend | grep webhook`

### Проблема: "Ошибка при создании попытки входа"

**Решение:**
```bash
# Убедитесь, что миграции применены
cd /root/arenda/infra
docker compose exec backend python manage.py migrate

# Проверьте, что таблица создана
docker compose exec backend python manage.py dbshell
# В PostgreSQL: \dt login_attempts
```

### Проблема: Пользователь не найден

**Проверьте:**
1. Номер телефона контрагента указан в базе данных
2. Номер в формате E.164 (+996XXXXXXXXX) или без +996
3. Проверьте логи: `docker compose logs backend | grep "Tenant not found"`

## ✅ Чеклист

- [ ] Миграции применены (`login_attempts` таблица создана)
- [ ] Webhook URL настроен в Green API
- [ ] Входящие уведомления включены
- [ ] Backend запущен и отвечает
- [ ] Nginx проксирует запросы правильно
- [ ] Endpoint `/api/auth/whatsapp/start/` работает
- [ ] Endpoint `/api/webhooks/greenapi/incoming/` доступен

## 🎯 После настройки

1. Откройте `http://assetmanagement.team/login`
2. Отсканируйте QR-код
3. Отправьте сообщение в WhatsApp
4. Вход должен пройти успешно!
