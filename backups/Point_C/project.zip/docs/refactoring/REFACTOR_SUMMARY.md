# Полный рефакторинг проекта - План и Статус

## 1. DESIGN SYSTEM & CLEANUP ✅

### Выполнено:
- ✅ Inter font уже настроен в `index.css` и `tailwind.config.js`
- ✅ Border-radius 12px настроен как `rounded-card` в `tailwind.config.js`
- ✅ Slate-Indigo палитра настроена в `tailwind.config.js`
- ✅ `lucide-react` добавлен в `package.json`
- ✅ Создан `ActionsMenu` компонент с React Portal
- ✅ Удалены дублирующиеся кнопки из всех форм:
  - ✅ PropertyForm
  - ✅ TenantForm
  - ✅ ContractForm
  - ✅ AccrualForm
  - ✅ AccountForm
- ✅ Все формы обновлены для использования `onSubmit` вместо `onSave/onCancel`
- ✅ Все Drawer компоненты обновлены с footer для кнопок
- ✅ PropertiesPage и TenantsPage обновлены для использования ActionsMenu
- ✅ ContractsPage обновлен для использования ActionsMenu

### В процессе:
- 🔄 Замена TableActions на ActionsMenu в остальных страницах (AccrualsPage, AccountsPage, PaymentsPage, DepositsPage)
- 🔄 Очистка неиспользуемых импортов и мертвого кода
- 🔄 Добавление useMemo/useCallback для оптимизации

## 2. CORE MODULES REFACTOR

### Accounts & Real Estate:
- 🔄 Компактные карточки с иконками валют
- 🔄 Таблицы с group-hover actions

### Contracts:
- 🔄 Рефакторинг формы в семантические группы (General, Terms, Financials) с 2-колоночной сеткой

### Accruals:
- 🔄 Summary карточки сверху (Total, Paid, Overdue)
- 🔄 Подсветка ТОЛЬКО статуса "Overdue" красным, не всей строки

### Deposits (NEW LOGIC):
- ⏳ Создание системы управления депозитами
- ⏳ Функции "Deduct" (списать) и "Refund" (вернуть)
- ⏳ Отслеживание баланса по договору

### Mailings (NEW LOGIC):
- ⏳ Две секции: "Scenario 1: Overdue" (приоритет) и "Scenario 2: General"
- ⏳ Автофильтрация получателей на основе выбранного шаблона
- ⏳ Инъекция переменных: {{name}}, {{amount}}, {{date}}

## 3. AUTH & RBAC

- ⏳ Логика аутентификации: Admin (Phone + Password), SuperAdmin, Clients (OTP)
- ⏳ Порталы для Tenants, Landlords, Investors, Masters

## 4. MOBILE RESPONSIVITY

- ✅ Layout уже имеет мобильную навигацию
- 🔄 Фиксированная нижняя навигация для мобильных
- ✅ ActionsMenu с Portal создан

## 5. INTEGRITY CHECK

- ⏳ Проверка всех ссылок и useNavigate
- ⏳ Проверка логики всех кнопок
- ⏳ Замена всех `any` типов
- ⏳ Проверка API вызовов

## Следующие шаги:
1. Завершить удаление кнопок из всех форм
2. Обновить все страницы для использования ActionsMenu
3. Рефакторить ContractForm в группы
4. Обновить AccrualsPage с summary карточками
5. Создать Deposits логику
6. Создать Mailings логику
7. Реализовать Auth & RBAC
8. Финальная проверка целостности
