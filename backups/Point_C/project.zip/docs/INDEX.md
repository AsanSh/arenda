# Документация проекта AMT

Навигация по всей документации проекта.

## 📚 Разделы документации

### 🚀 Настройка и установка
**Расположение:** `docs/setup/`

- [Быстрый старт](setup/QUICK_START.md)
- [Настройка домена](setup/DOMAIN_SETUP.md)
- [Настройка WhatsApp авторизации](setup/WHATSAPP_LOGIN_INSTRUCTIONS.md)
- [Настройка Green API](setup/GREEN_API_SETUP.md)
- [SSH настройка](setup/SSH_SETUP.md)
- [Миграции базы данных](setup/MIGRATION_INSTRUCTIONS.md)

### 🔧 Исправления и решения проблем
**Расположение:** `docs/fixes/`

- [История исправлений](fixes/fixes-log.md) - **Единый файл со всеми исправлениями**
- Старые файлы исправлений (архив)

**Важно:** При появлении новой ошибки добавляйте запись в `fixes/fixes-log.md`, а не создавайте новый файл!

### 🔄 Рефакторинг
**Расположение:** `docs/refactoring/`

- [Прогресс рефакторинга](refactoring/REFACTOR_PROGRESS.md)
- [Итоги рефакторинга](refactoring/REFACTOR_COMPLETED.md)
- [Сводка рефакторинга](refactoring/REFACTOR_SUMMARY.md)

### 💾 Точки восстановления
**Расположение:** `docs/restore-points/`

- [Point A](restore-points/POINT_A_RESTORE.md)
- [Point B](restore-points/POINT_B.md)

## 📝 Как добавлять новую документацию

### При исправлении ошибки:
1. Откройте `docs/fixes/fixes-log.md`
2. Добавьте новую запись в начало файла (после заголовка)
3. Укажите дату, проблему, решение и затронутые файлы
4. **НЕ создавайте новый файл FIX_*.md**

### При добавлении инструкции по настройке:
1. Создайте файл в `docs/setup/`
2. Используйте понятное имя: `SETUP_НАЗВАНИЕ.md`
3. Обновите этот индексный файл

### При создании точки восстановления:
1. Создайте файл в `docs/restore-points/`
2. Используйте формат: `POINT_X.md`
3. Обновите этот индексный файл

## 🔍 Быстрый поиск

- **Проблемы с доменом?** → `docs/setup/DOMAIN_*.md`
- **Проблемы с авторизацией?** → `docs/fixes/fixes-log.md` (раздел CSRF/WhatsApp)
- **Нужна точка восстановления?** → `docs/restore-points/`
- **Как настроить проект?** → `docs/setup/QUICK_START.md`
