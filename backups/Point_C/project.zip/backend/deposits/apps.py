from django.apps import AppConfig


class DepositsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'deposits'
    verbose_name = 'Депозиты'
